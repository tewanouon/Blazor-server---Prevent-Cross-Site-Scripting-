
namespace Blazor_Cross_Site_v2.Services
{
    public static class _Compat { }
}

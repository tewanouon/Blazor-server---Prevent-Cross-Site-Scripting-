
using Ganss.Xss;

namespace Blazor_Cross_Site_v3.Services
{
    public class HtmlSanitizerService
    {
        private readonly HtmlSanitizer _sanitizer;

        public HtmlSanitizerService(HtmlSanitizer sanitizer)
        {
            _sanitizer = sanitizer;
            _sanitizer.AllowedTags.Add("h1");
            _sanitizer.AllowedTags.Add("h2");
            _sanitizer.AllowedAttributes.Add("class");
            _sanitizer.AllowedSchemes.Add("data");
        }

        public string Sanitize(string html) => _sanitizer.Sanitize(html);
    }
}


namespace Blazor_Cross_Site_v3.Services
{
    public class SessionCsrfService
    {
        public const string SessionKey = "CSRF-TOKEN";

        public string EnsureToken(HttpContext httpContext)
        {
            var token = httpContext.Session.GetString(SessionKey);
            if (string.IsNullOrEmpty(token))
            {
                token = Guid.NewGuid().ToString("N");
                httpContext.Session.SetString(SessionKey, token);
            }
            return token;
        }

        public bool Validate(HttpContext httpContext, string? requestToken)
        {
            var sessionToken = httpContext.Session.GetString(SessionKey);
            return !string.IsNullOrEmpty(sessionToken) && sessionToken == requestToken;
        }
    }
}

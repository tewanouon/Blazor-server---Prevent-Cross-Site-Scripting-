
using Ganss.Xss;
using Microsoft.AspNetCore.Mvc;
using Blazor_Cross_Site_v2.Services; // as requested (compat provided)
using Blazor_Cross_Site_v3.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();
builder.Services.AddControllersWithViews();

// Session
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.Cookie.Name = ".BlazorCrossSiteV3.Session";
    options.Cookie.HttpOnly = true;
    options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
    options.Cookie.SameSite = SameSiteMode.Lax;
    options.IdleTimeout = TimeSpan.FromMinutes(30);
});

// HtmlSanitizer
builder.Services.AddSingleton<HtmlSanitizer>();
builder.Services.AddScoped<HtmlSanitizerService>();

// CSRF (session-based)
builder.Services.AddScoped<SessionCsrfService>();

builder.Services.AddHttpClient();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseSession();

app.MapControllers();
app.MapBlazorHub();
app.MapFallbackToPage("/_Host");

app.Run();


using Microsoft.AspNetCore.Mvc;
using Blazor_Cross_Site_v3.Services;

namespace Blazor_Cross_Site_v3.Controllers
{
    [ApiController]
    [Route("api/session-csrf")]
    public class SessionCsrfController : ControllerBase
    {
        private readonly SessionCsrfService _csrf;

        public SessionCsrfController(SessionCsrfService csrf)
        {
            _csrf = csrf;
        }

        [HttpGet("token")]
        public ActionResult<string> GetToken()
        {
            var token = _csrf.EnsureToken(HttpContext);
            return Ok(token);
        }
    }
}

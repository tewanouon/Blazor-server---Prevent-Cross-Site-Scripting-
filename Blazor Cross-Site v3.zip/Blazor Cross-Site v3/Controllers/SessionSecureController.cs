
using Microsoft.AspNetCore.Mvc;
using Blazor_Cross_Site_v3.Services;
using Blazor_Cross_Site_v3.Models;

namespace Blazor_Cross_Site_v3.Controllers
{
    [ApiController]
    [Route("api/session-secure")]
    public class SessionSecureController : ControllerBase
    {
        private readonly SessionCsrfService _csrf;

        public SessionSecureController(SessionCsrfService csrf)
        {
            _csrf = csrf;
        }

        [HttpPost("echo")]
        public IActionResult Echo([FromBody] EchoRequest req)
        {
            Request.Headers.TryGetValue("X-CSRF-TOKEN", out var token);
            if (!_csrf.Validate(HttpContext, token.FirstOrDefault()))
            {
                return Unauthorized("Invalid CSRF token");
            }

            return Ok($"Echo: {req.Text}");
        }
    }
}

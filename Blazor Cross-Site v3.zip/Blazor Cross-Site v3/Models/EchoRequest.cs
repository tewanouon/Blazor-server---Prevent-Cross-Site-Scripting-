
namespace Blazor_Cross_Site_v3.Models
{
    public record EchoRequest(string Text);
}
